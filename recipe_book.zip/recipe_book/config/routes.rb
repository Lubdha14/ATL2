Rails.application.routes.draw do
  get 'recipes/index'
  get 'recipes/show/:id', to: 'recipes#show', as: 'recipe'
  get 'recipes/new'
  post 'recipes/create', to: 'recipes#create'
  get 'recipes/edit/:id', to: 'recipes#edit', as: 'edit_recipe'
  patch 'recipes/update/:id', to: 'recipes#update', as: 'update_recipe'
  delete 'recipes/destroy/:id', to: 'recipes#destroy', as: 'destroy_recipe'
  root 'recipes#index'
end
