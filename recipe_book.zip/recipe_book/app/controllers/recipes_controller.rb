class RecipesController < ApplicationController
    @@recipes = [
      { 
        id: 1, 
        name: 'Pasta Carbonara', 
        description: 'Creamy Italian pasta dish',
        steps: [
          'Cook pasta according to package instructions.',
          'In a skillet, cook pancetta until crispy.',
          'In a bowl, whisk together eggs, cheese, and pepper.',
          'Drain pasta and add to skillet with pancetta.',
          'Remove from heat and stir in egg mixture.'
        ]
      },
      { 
        id: 2, 
        name: 'Chicken Curry', 
        description: 'Spicy Indian chicken curry',
        steps: [
          'Heat oil in a pan and sauté onions until translucent.',
          'Add chicken pieces and cook until browned.',
          'Stir in curry paste and cook for 2 minutes.',
          'Add coconut milk, cover, and simmer for 20 minutes.',
          'Season with salt, pepper, and garnish with cilantro.'
        ]
      },
      { 
        id: 3, 
        name: 'Chocolate Cake', 
        description: 'Decadent chocolate cake with frosting',
        steps: [
          'Preheat oven to 350°F (175°C).',
          'In a bowl, mix flour, cocoa powder, baking soda, and salt.',
          'In another bowl, cream butter and sugar until fluffy.',
          'Add eggs one at a time, then vanilla.',
          'Mix in dry ingredients alternately with milk.',
          'Pour batter into greased cake pans and bake for 30-35 minutes.',
          'Cool cakes completely before frosting.'
        ]
      },
      { 
        id: 4, 
        name: 'Caesar Salad', 
        description: 'Classic salad with romaine lettuce, croutons, and Caesar dressing',
        steps: [
          'Wash and chop romaine lettuce.',
          'In a large bowl, toss lettuce with Caesar dressing.',
          'Add croutons and grated Parmesan cheese.',
          'Toss again and serve immediately.'
        ]
      },
      { 
        id: 5, 
        name: 'Beef Tacos', 
        description: 'Tacos filled with seasoned beef, lettuce, cheese, and salsa',
        steps: [
          'Brown ground beef in a skillet.',
          'Stir in taco seasoning and water.',
          'Simmer until liquid evaporates.',
          'Warm taco shells in the oven.',
          'Fill taco shells with beef mixture, lettuce, cheese, and salsa.'
        ]
      }
    ]
    def index
      @recipes = @@recipes
    end
  
    def show
      @recipe = @@recipes.find { |recipe| recipe[:id] == params[:id].to_i }
    end
  
    def new
    end
  
    def create
      id = @@recipes.last[:id] + 1
      @@recipes << { id: id, name: params[:name], description: params[:description] }
      redirect_to root_path
    end
  
    def edit
      @recipe = @@recipes.find { |recipe| recipe[:id] == params[:id].to_i }
    end
  
    def update
      recipe = @@recipes.find { |recipe| recipe[:id] == params[:id].to_i }
      recipe[:name] = params[:name]
      recipe[:description] = params[:description]
      redirect_to root_path
    end
  
    def destroy
      @@recipes.reject! { |recipe| recipe[:id] == params[:id].to_i }
      redirect_to root_path
    end
  end
  